package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;

import java.util.List;

public interface BookService {
    List<Book> findAll();
    Book findById(Long id);
    Book save(String title, String genre, Double avgRating,Author author);
    Book update(Long id,String title,String genre,Double avgRating,Author author);
    void deleteById(Long id);
    List<Book> findByAuthorId(Long authorId);

}
