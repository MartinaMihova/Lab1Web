package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer {
    private final AuthorRepository authorRepository;
    private final BookRepository bookRepository;

    public DataInitializer(AuthorRepository authorRepository,
                           BookRepository bookRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
    }

    @PostConstruct
    public void init() {

        if (authorRepository.count() == 0) {

            Author orwell = authorRepository.save(
                    new Author("George", "Orwell", "United Kingdom", "Author of 1984")
            );
            Author rowling = authorRepository.save(
                    new Author("J.K.", "Rowling", "United Kingdom", "Harry Potter writer")
            );
            Author murakami = authorRepository.save(
                    new Author("Haruki", "Murakami", "Japan", "Kafka on the Shore")
            );

            bookRepository.save(new Book("1984", "Dystopian", 4.7, orwell));
            bookRepository.save(new Book("Animal Farm", "Satire", 4.4, orwell));
            bookRepository.save(new Book("Harry Potter 1", "Fantasy", 4.8, rowling));
            bookRepository.save(new Book("Kafka on the Shore", "Magic realism", 4.3, murakami));
        }
    }
}
