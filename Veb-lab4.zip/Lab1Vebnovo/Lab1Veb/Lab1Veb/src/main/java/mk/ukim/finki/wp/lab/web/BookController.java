package mk.ukim.finki.wp.lab.web;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.service.AuthorService;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
public class BookController {
    private final BookService bookService;
    private final AuthorService authorService;

    public BookController(BookService bookService, AuthorService authorService) {
        this.bookService = bookService;
        this.authorService = authorService;
    }

    @GetMapping
    public String getBooksPage(@RequestParam(required = false)String error, Model model){
        List<Book> books = bookService.findAll();
        model.addAttribute("books",books);

        model.addAttribute("authors", authorService.findAll());

        if(error != null && !error.isEmpty()){
            model.addAttribute("hasError",true);
            model.addAttribute("error",error);
        }
        return "listBooks";
    }

    @PostMapping("/add")
    public String saveBook(@RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId){
        Author author=authorService.findById(authorId);
        bookService.save(title,genre,averageRating,author);
        return "redirect:/books";
    }

    @PostMapping("/edit/{bookId}")
    public String editBook(@PathVariable Long bookId,
                           @RequestParam String title,
                           @RequestParam String genre,
                           @RequestParam Double averageRating,
                           @RequestParam Long authorId){
        Author author=authorService.findById(authorId);
        bookService.update(bookId,title,genre,averageRating,author);
        return "redirect:/books";
    }

    @PostMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id){
        bookService.deleteById(id);
        return "redirect:/books";
    }

    @GetMapping("/book-form/{id}")
    public String getEditBookForm(@PathVariable Long id, Model model){
        Book book=bookService.findById(id);
        if(book==null){
            return "redirect:/books?error=BookNotFound";
        }
        model.addAttribute("book",book);
        model.addAttribute("authors",authorService.findAll());
        return "book-form";
    }

    @GetMapping("/book-form")
    public String getAddBookPage(Model model){
        model.addAttribute("book", null);
        model.addAttribute("authors",authorService.findAll());

        return "book-form";
    }

    @GetMapping("/authors/{authorId}")
    public String getBooksByAuthor(@PathVariable Long authorId, Model model) {

        List<Book> books = bookService.findByAuthorId(authorId);

        model.addAttribute("books", books);
        model.addAttribute("authors", authorService.findAll());

        return "listBooks";
    }

}
