package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Book> books=new ArrayList<>();
    public static List<BookReservation> reservations=new ArrayList<>();

    @PostConstruct
    public void init(){
        books.add(new Book("Harry Potter and the Philosopher's Stone","Fantasy",4.6));
        books.add(new Book("Harry Potter and the Chapter of Secrets","Fantasy",4.4));
        books.add(new Book("Harry Potter and the Prisoner of Azkaban","Fantasy",4.5));
        books.add(new Book("Harry Potter and the Goblet of Fire","Fantasy",4.5));
        books.add(new Book("Harry Potter and the Order of Phoenix","Fantasy",4.5));
        books.add(new Book("Harry Potter and the Half-Blood Prince","Fantasy",4.7));
        books.add(new Book("Harry Potter and the Deathly Hallows","Fantasy",4.6));
        books.add(new Book("The Hobbit","Adventure",4.2));
        books.add(new Book("The Hunger Games","Science Fiction",4.3));
        books.add(new Book("The Lord of the Rings: The Fellowship of the Ring","Fantasy",4.3));
    }
}
