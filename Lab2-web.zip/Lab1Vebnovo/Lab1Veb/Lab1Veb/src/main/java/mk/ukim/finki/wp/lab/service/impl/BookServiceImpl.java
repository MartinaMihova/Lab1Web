package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import mk.ukim.finki.wp.lab.service.AuthorService;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final AuthorService authorService;

    public BookServiceImpl(BookRepository bookRepository, AuthorService authorService) {
        this.bookRepository = bookRepository;
        this.authorService = authorService;
    }

    @Override
    public List<Book> listAll() {
        return bookRepository.findAll();
    }

    @Override
    public List<Book> searchBooks(String text, double rating) {
        return bookRepository.searchBooks(text,rating);
    }

    @Override
    public List<Book> findAll() {
        return bookRepository.findAll();
    }

    @Override
    public Book save(String title, String genre, Double avgRating,Author author) {
        Book book=new Book(title,genre,avgRating,author);
        return bookRepository.save(book);
    }

    @Override
    public Book update(Long id, String title, String genre, Double avgRating, Author author) {
        Book book=this.bookRepository.findById(id)
                .orElseThrow(()->new RuntimeException("Book not found with id: "+ id));
        book.setTitle(title);
        book.setGenre(genre);
        book.setAverageRating(avgRating);
        book.setAuthor(author);

        return this.bookRepository.save(book);
    }

    @Override
    public void deleteById(Long id) {
        bookRepository.delete(id);
    }

    @Override
    public Book findById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }
}
