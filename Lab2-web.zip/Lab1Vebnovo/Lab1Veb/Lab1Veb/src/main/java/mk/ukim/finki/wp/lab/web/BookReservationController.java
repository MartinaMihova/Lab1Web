package mk.ukim.finki.wp.lab.web;

import jakarta.servlet.http.HttpServletRequest;
import mk.ukim.finki.wp.lab.service.BookReservationService;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/bookReservation")
public class BookReservationController {
    private final BookReservationService bookReservationService;
    private final BookService bookService;

    public BookReservationController(BookReservationService bookReservationService, BookService bookService) {
        this.bookReservationService = bookReservationService;
        this.bookService = bookService;
    }


    @GetMapping
    public String getReservationConfirmation(@RequestParam String bookTitle,
                                             @RequestParam String readerName,
                                             @RequestParam String numberOfCopies,
                                             HttpServletRequest request,
                                             Model model){
        model.addAttribute("readerName",readerName);
        model.addAttribute("bookTitle",bookTitle);
        model.addAttribute("numberOfCopies",numberOfCopies);
        model.addAttribute("ipAddress", request.getRemoteAddr());
        return "reservationConfirmation";
    }


    @PostMapping
    public String placeReservation(@RequestParam String bookTitle,
                                   @RequestParam String readerName,
                                   @RequestParam String readerAddress,
                                   @RequestParam int numCopies){
        bookReservationService.placeReservation(bookTitle,readerName,readerAddress,numCopies);
        return String.format(
                  "redirect:/bookReservation?bookTitle=%s&readerName=%s&numberOfCopies=%s",
                         bookTitle,readerName,numCopies
        );
    }
}
