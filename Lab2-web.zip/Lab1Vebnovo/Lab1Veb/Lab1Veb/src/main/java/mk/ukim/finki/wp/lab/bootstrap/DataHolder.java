package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.BookReservation;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Book> books=new ArrayList<>();
    public static List<BookReservation> reservations=new ArrayList<>();
    public static List<Author> authors = new ArrayList<>();

    @PostConstruct
    public void init(){

        Author author1 = new Author("George", "Orwell", "United Kingdom", "Author of '1984' and 'Animal Farm'");
        Author author2 = new Author("J.K.", "Rowling", "United Kingdom", "Author of the Harry Potter series");
        Author author3 = new Author("Haruki", "Murakami", "Japan", "Japanese writer known for surreal novels");

        authors.add(author1);
        authors.add(author2);
        authors.add(author3);

        books.add(new Book("Harry Potter and the Philosopher's Stone","Fantasy",4.6,author2));
        books.add(new Book("Harry Potter and the Chapter of Secrets","Fantasy",4.4,author3));
        books.add(new Book("Harry Potter and the Prisoner of Azkaban","Fantasy",4.5,author2));
        books.add(new Book("Harry Potter and the Goblet of Fire","Fantasy",4.5,author2));
        books.add(new Book("Harry Potter and the Order of Phoenix","Fantasy",4.5,author2));
        books.add(new Book("Harry Potter and the Half-Blood Prince","Fantasy",4.7,author2));
        books.add(new Book("Harry Potter and the Deathly Hallows","Fantasy",4.6,author2));
        books.add(new Book("The Hobbit","Adventure",4.2,author2));
        books.add(new Book("The Hunger Games","Science Fiction",4.3,author2));
        books.add(new Book("The Lord of the Rings: The Fellowship of the Ring","Fantasy",4.3,author2));

    }
}
